function [n, set_indices] = count_sets_with_indices(cards)
% count_sets_with_indices : 주어진 보드에서 유효한 세트의 개수와 해당 세트 조합의 인덱스를 반환


% 입력:
%   cards - 구조체 배열 (예: 12장의 카드)
%
% 출력:
%   n - 유효한 세트의 개수
%   set_indices - 세트를 이루는 카드들의 인덱스를 담은 Nx3 배열

    n = 0;              % 세트 개수 초기화
    set_indices = [];   % 세트 인덱스 리스트 초기화

    comb = nchoosek(1:length(cards), 3);  % 카드 3장 조합 생성 (12C3 = 220개)

    % 모든 3장 조합에 대해 세트 여부 판단
    for i = 1:size(comb, 1)
        c1 = cards(comb(i, 1));
        c2 = cards(comb(i, 2));
        c3 = cards(comb(i, 3));

        % is_valid_set 함수로 세트 여부 확인
        if is_valid_set(c1, c2, c3)
            n = n + 1;                           % 유효 세트 개수 증가
            set_indices = [set_indices; comb(i, :)];  % 세트 인덱스 추가

            % 디버깅 출력 (세트의 속성 정보)
            fprintf('[SET] (%d, %d, %d): %s-%s-%s / %s-%s-%s / %s-%s-%s\n', ...
                comb(i,1), comb(i,2), comb(i,3), ...
                c1.shape, c1.color, c1.pattern, ...
                c2.shape, c2.color, c2.pattern, ...
                c3.shape, c3.color, c3.pattern);
        end
    end
end
