function set_cards = generate_structured_valid_set(num_same)
% generate_structured_valid_set
% 주어진 동일 속성 수(num_same)에 따라 3장의 유효한 세트 카드 생성

% 입력:
%   num_same - 3장의 카드가 공유할 속성 수 (예: 2이면 2개 속성은 동일, 나머지 2개는 모두 다름)
%
% 출력:
%   set_cards - 3장의 카드로 구성된 유효한 세트


    % 카드 속성 정의 (속성 이름 및 가능한 값들)
    attr_names = {'shape', 'color', 'pattern', 'number'};

    attr_values = {
        {'square', 'circle', 'triangle'}, ...   % 도형 모양
        {'red', 'yellow', 'blue'}, ...          % 색상
        {'shade', 'empty', 'filled'}, ...       % 패턴
        {'one', 'two', 'three'}                 % 개수
    };
    num_attrs = numel(attr_names);  % 총 속성 수 = 4

    all_cards = generate_all_cards();  % 전체 카드 풀 (3^4 = 81장)
    raw_set = repmat(struct(), 1, 3);  % 초기 빈 카드 3장 생성

    while true 

        % 어떤 속성들이 동일하게 유지될지를 랜덤으로 선택
        same_flags = zeros(1, num_attrs);             % 동일 여부 플래그 초기화
        same_idx = randperm(num_attrs, num_same);     % 동일하게 만들 속성 인덱스 무작위 선택
        same_flags(same_idx) = 1;

        % 속성별로 카드 세 장 구성
        for attr_idx = 1:num_attrs
            options = attr_values{attr_idx};          % 현재 속성의 가능한 값들
            field = attr_names{attr_idx};             % 현재 속성 이름

            if same_flags(attr_idx) == 1
                % 해당 속성은 3장 모두 동일한 값 부여
                val = options{randi(3)};
                for k = 1:3
                    raw_set(k).(field) = val;
                end
            else
                % 해당 속성은 3장 모두 서로 다른 값 부여
                vals = options(randperm(3));
                for k = 1:3
                    raw_set(k).(field) = vals{k};
                end
            end
        end

        % all_cards 구조에 맞게 실제 카드 구조체 추출
        attr_names_all = fieldnames(all_cards);  % 전체 속성 이름 추출
        empty_template = cell2struct(repmat({[]}, size(attr_names_all)), attr_names_all, 1);  % 빈 카드 템플릿

        set_cards = repmat(empty_template, 1, 3);  % 결과 카드 배열 초기화

        % 생성한 카드 정보(raw_set)를 all_cards에서 실제 구조체로 매핑
        for k = 1:3
            mask = ismember_structs(all_cards, raw_set(k));  % 해당 카드가 all_cards에 있는지 확인
            idx = find(mask, 1);  % 첫 번째 일치 인덱스 찾기
            if isempty(idx)
                error('카드 %d가 all_cards에 없음', k);  % 예외 처리
            end
            set_cards(k) = all_cards(idx);  % 일치하는 카드 저장
        end

        return;  % 유효한 세트 생성 완료 시 반환
    end
end
