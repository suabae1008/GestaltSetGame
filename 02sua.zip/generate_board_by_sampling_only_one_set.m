function board = generate_board_by_sampling_only_one_set(set_cards)
% generate_board_by_sampling_only_one_set
% 주어진 세트(set_cards) 1개만 포함되도록 나머지 9장의 카드를 샘플링하여 12장 보드 생성
% 중복 세트를 제거하기 위해 위험도 기반 교체 휴리스틱 사용

    max_attempts = 10;  % 9장의 후보 카드를 샘플링할 최대 시도 횟수

    while true

       
        fprintf('\n[SET 생성]\n');
        for i = 1:3
            fprintf('  카드%d: %s-%s-%s-%s\n', i, ...
                set_cards(i).shape, set_cards(i).color, set_cards(i).pattern, set_cards(i).number);
        end

        %% 1. 전체 카드 중 세트 3장을 제거하고 나머지에서 후보군 생성

        all_cards = generate_all_cards();  % 전체 81장
        used_mask = ismember_structs(all_cards, set_cards);  % 세트에 포함된 카드 마스크

        candidates = all_cards(~used_mask);  % 세트를 제외한 후보 카드

        %% 2. 9장 후보 카드를 무작위 샘플링 → 세트 1개만 존재하는지 확인

        for attempt = 1:max_attempts

            sample_idx = randperm(length(candidates), 9);
            board = [set_cards, candidates(sample_idx).'];  % 12장 보드 구성

            [set_count, set_indices] = count_sets_with_indices(board);  % 세트 개수 계산

            fprintf('[CHECK] 시도 #%d → 세트 개수: %d\n', attempt, set_count);
    
            % 세트가 1개만 존재하면 보드 생성 성공
            if set_count == 1
                fprintf('[DONE] 보드 완성! 🎯 시도 #%d\n', attempt);
                fprintf('\n[📋 완성된 보드 카드 목록]\n');
                for i = 1:length(board)
                    fprintf('%2d: %s-%s-%s\n', i, ...
                        board(i).shape, board(i).color, board(i).pattern);
                end
                return;
            end

            %% === 세트가 여러 개인 경우: 교체 알고리즘 시작 ===

            fprintf('\n🔁 세트가 1개 초과이므로 교체 시도 시작...\n');

            fixed_indices = 1:3;  % 초기 세트 카드는 고정
            max_swaps = 10;       % 최대 교체 횟수 제한
            swap_count = 0;

            while set_count > 1 && swap_count < max_swaps
                swap_count = swap_count + 1;

                % 1. 각 카드가 세트에 몇 번 포함되었는지 계산
                card_count = zeros(1, length(board));
                for i = 1:size(set_indices, 1)
                    for j = 1:3
                        card_count(set_indices(i, j)) = card_count(set_indices(i, j)) + 1;
                    end
                end
                
                [~, sorted_indices] = sort(card_count, 'descend');  % 가장 많이 포함된 순서로 정렬

                % 2. 고정카드 제외하고 교체 가능한 카드 선택
                target_idx = -1;
                for i = 1:length(sorted_indices)
                    idx = sorted_indices(i);
                    if ~ismember(idx, fixed_indices) && card_count(idx) > 0
                        target_idx = idx;
                        break;
                    end
                end

                if target_idx == -1
                    fprintf('[!] 교체 가능한 카드가 없음\n');
                    break;
                end

                % 3. 후보 중에서 위험도(score)가 가장 낮은 카드 선택
                board_candidates = all_cards(~ismember_structs(all_cards, board));  % 아직 사용되지 않은 카드들

                best_score = inf;
                best_candidate = struct();
                best_candidate_idx = -1;

                for i = 1:length(board_candidates)
                    temp_board = board;
                    temp_board(target_idx) = board_candidates(i);
                    danger = compute_danger_score(board_candidates(i), temp_board, 'simple');

                    if danger < best_score
                        best_score = danger;
                        best_candidate = board_candidates(i);
                        best_candidate_idx = i;
                    end
                end

                % 4. 카드 교체 수행
                fprintf('[SWAP %d] 카드 %d (%s-%s-%s) → 후보 %d (%s-%s-%s), 위험도 %.2f\n', ...
                    swap_count, ...
                    target_idx, board(target_idx).shape, board(target_idx).color, board(target_idx).pattern, ...
                    best_candidate_idx, best_candidate.shape, best_candidate.color, best_candidate.pattern, best_score);

                board(target_idx) = board_candidates(best_candidate_idx);  % 보드 업데이트

                % 세트 재확인
                [set_count, set_indices] = count_sets_with_indices(board);
                fprintf('[INFO] 교체 후 세트 개수: %d\n', set_count);

                % 성공 시 종료
                if set_count == 1
                    fprintf('[DONE] 보드 완성! 🎯 시도 #%d\n', attempt);
                    fprintf('\n[📋 완성된 보드 카드 목록]\n');
                    for i = 1:length(board)
                        fprintf('%2d: %s-%s-%s-%s\n', i, ...
                            board(i).shape, board(i).color, board(i).pattern, board(i).number);
                    end
                    return;
                end
            end
        end

        % 모든 시도 실패 시, 세트를 새로 뽑고 재시도
        fprintf('못 찾겠어요\n');
        return;
    end
end
