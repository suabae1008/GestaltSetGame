function all_cards = generate_all_cards()
% generate_all_cards :  Set 게임의 모든 가능한 카드 조합(총 81장)을 생성하는 함수


% 출력:
%   all_cards - 각 속성값 조합을 갖는 구조체 배열 (shape, color, pattern, number)

    %% 1. 카드 속성 이름 및 가능한 값 정의
    attr_names = {'shape', 'color', 'pattern', 'number'};
    attr_values = {
        {'square', 'circle', 'triangle'}, ...  % 도형 모양
        {'red', 'yellow', 'blue'}, ...         % 색상
        {'shade', 'empty', 'filled'}, ...      % 패턴
        {'one', 'two', 'three'}                % 개수
    };

    %% 2. 속성별 가능한 조합 수 계산
    num_attrs = numel(attr_names);       % 총 속성 수 = 4
    grid = cell(1, num_attrs);           % 속성별 조합 결과 저장할 셀 배열
    [grid{:}] = ndgrid(attr_values{:});  % ndgrid를 이용해 모든 조합 생성 (3^4 = 81개)
    total = numel(grid{1});              % 전체 카드 수 (81장)

    %% 3. 각 조합을 구조체로 변환하여 카드 배열 생성
    all_cards = repmat(struct(), total, 1);  % 빈 구조체 배열 초기화
    for i = 1:total
        for a = 1:num_attrs
            all_cards(i).(attr_names{a}) = grid{a}(i);  % 속성별 값 할당
        end
    end

    %% 4. 셀 내부 값이 중첩되어 있을 경우, 실제 문자열로 추출
    for i = 1:total
        for a = 1:num_attrs
            val = all_cards(i).(attr_names{a});
            if iscell(val)
                all_cards(i).(attr_names{a}) = val{1};  % 중첩 제거
            end
        end
    end
end
