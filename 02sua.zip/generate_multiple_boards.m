function boards = generate_multiple_boards(n, m)
% generate_multiple_boards : 2-same 세트와 1-same 세트를 포함하는 게임 보드들을 생성하는 함수


% 입력:
%   n - 생성할 2-same 보드의 수
%   m - 생성할 1-same 보드의 수
%
% 출력:
%   boards - 생성된 보드 구조체 배열 (각 보드는 12장의 카드 포함)

    % 기본값 설정 
    if nargin < 1
        n = 5;
        m = 5;
    end

    total = n + m;  % 총 보드 수
    boards = repmat(struct('cards', [], 'set_type', ''), 1, total);  % 결과 배열 초기화
    count = 0;  % 현재까지 생성된 보드 수

    fprintf('[생성 시작] 2-same %d개, 1-same %d개\n', n, m);

    %% 1. 2-same 보드 생성 루프
    for i = 1:n
        while true
            try
                % 세트 조건 2개가 동일한 세트 생성
                set_cards = generate_structured_valid_set(2);

                % 해당 세트를 기반으로 보드 생성 (*이때, 세트 1개만 포함되도록 구성)
                board = generate_board_by_sampling_only_one_set(set_cards);

                % 생성된 보드를 결과에 저장
                count = count + 1;
                boards(count).cards = board;
                boards(count).set_type = '2-same';

                fprintf('[%d/%d] 2-same 보드 생성 완료\n', count, total);
                break;  % 성공 시 루프 탈출
            catch
                % 보드 생성 실패 시 세트 카드를 재생성하며 다시 시도 (* heuristic + greedy 알고리즘 기반이므로 세트가 생성되지 않을 수도 있음)
            end
        end
    end

    %% 2. 1-same 보드 생성 루프
    for i = 1:m
        while true
            try
                % 세트 조건 1개가 동일한 세트 생성
                set_cards = generate_structured_valid_set(1);

                % 해당 세트를 기반으로 보드 생성
                board = generate_board_by_sampling_only_one_set(set_cards);

                % 생성된 보드를 결과에 저장
                count = count + 1;
                boards(count).cards = board;
                boards(count).set_type = '1-same';

                fprintf('[%d/%d] 1-same 보드 생성 완료\n', count, total);
                break;
            catch
                % 실패 시 반복
            end
        end
    end

    fprintf('\n✅ 모든 보드 생성 완료: 총 %d개\n', total);
end
