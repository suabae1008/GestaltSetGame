function mask = ismember_structs(big, small)
% ismember_structs : 두 구조체 배열 간 항목 비교를 수행하여, big 배열의 각 원소가 small 배열 안에 존재하는지 여부를 논리값 벡터로 반환


% 입력:
%   big   - 비교 대상 구조체 배열 (크기가 큰 배열)
%   small - 참조 구조체 배열 (찾고자 하는 항목들)
%
% 출력:
%   mask  - 논리값 벡터 (1 x length(big)), 각 원소가 small에 존재하면 true

    % 입력이 비어 있으면 바로 false 반환
    if isempty(big) || isempty(small)
        mask = false(1, length(big));
        return;
    end

    % 구조체의 필드 이름 추출 (모든 필드는 동일하다고 가정)
    attr_names = fieldnames(big);

    mask = false(1, length(big));  % 반환용 마스크 초기화
    for i = 1:length(big)
        for j = 1:length(small)
            is_match = true;  % 일치 여부 초기값

            % 모든 속성(attr_names)을 순회하며 필드값 비교
            for a = 1:numel(attr_names)
                field = attr_names{a};
                if ~isequal(big(i).(field), small(j).(field))
                    is_match = false;  % 하나라도 다르면 일치 아님
                    break;
                end
            end

            if is_match
                mask(i) = true;  % 일치하는 small(j)가 발견되면 true 표시
                break;  % 더 이상 비교할 필요 없음
            end
        end
    end
end
